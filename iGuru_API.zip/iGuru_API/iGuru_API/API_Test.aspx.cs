﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iGuru_API
{
    public partial class API_Test : System.Web.UI.Page
    {
        APITest oclsAPI = new APITest();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }
        protected void BindData()
        {
            ViewState["VwItemDetails"] = null;
            txtItemCode.Text = "1";
            DataTable _dtItem = new DataTable();
            _dtItem.Columns.Add("ItemCode", typeof(int));
            _dtItem.Columns.Add("product_tax_code", typeof(string));
            _dtItem.Columns.Add("Quantity", typeof(int));
            _dtItem.Columns.Add("unit_price", typeof(decimal));
            _dtItem.Columns.Add("discount", typeof(decimal));
            ViewState["VwItemDetails"] = _dtItem;
        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {
            oclsAPI = new APITest();

            DataTable dtChk = (DataTable)ViewState["VwItemDetails"];
            if (dtChk != null)
            {

                if (Convert.ToString(drp_Location.SelectedValue) != "")
                {
                    string[] _LocationDetails = Convert.ToString(drp_Location.SelectedValue).Split(',');
                    if (_LocationDetails.Length > 0)
                    {
                        oclsAPI.city = _LocationDetails[0].Trim();
                        oclsAPI.state = _LocationDetails[1].Trim();
                        oclsAPI.country = _LocationDetails[2].Trim();
                        oclsAPI.Zip = _LocationDetails[3].Trim();
                        oclsAPI.dt = dtChk;
                        oclsAPI.Shipping = Convert.ToDecimal(lblShip.Text);
                        string _result = oclsAPI.CalculateTax();

                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + _result + "')", true);

                    }
                }


            }

        }
        protected void gvItemDetails_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DataTable dtChk = (DataTable)ViewState["VwItemDetails"];
            if (dtChk != null)
            {
                DataRow[] _dr = dtChk.Select("ItemCode='" + txtItemCode.Text + "'");
                if (_dr.Length > 0)
                {
                    _dr[0]["product_tax_code"] = "20010";
                    _dr[0]["Quantity"] = Convert.ToInt32(txtQuantity.Text);
                    _dr[0]["unit_price"] = Convert.ToDecimal(txtPrice.Text);
                    _dr[0]["discount"] = Convert.ToDecimal(txtDisc.Text);
                }
                else
                {
                    DataRow drIns = dtChk.NewRow();
                    drIns["ItemCode"] = txtItemCode.Text;
                    drIns["product_tax_code"] = "20010";
                    drIns["Quantity"] = Convert.ToInt32(txtQuantity.Text);
                    drIns["unit_price"] = Convert.ToDecimal(txtPrice.Text);
                    drIns["discount"] = Convert.ToDecimal(txtDisc.Text == "" ? "0" : txtDisc.Text);
                    dtChk.Rows.Add(drIns);
                }

                dtChk.AcceptChanges();
                ViewState["VwItemDetails"] = dtChk;
                txtItemCode.Text = (dtChk.Rows.Count + 1).ToString();

                txtDisc.Text = "";
                txtPrice.Text = "";
                txtQuantity.Text = "";

                gvItemDetails.DataSource = dtChk;
                gvItemDetails.DataBind();

            }

        }

        protected void btnView_Click(object sender, EventArgs e)
        {
            if (Convert.ToString(drp_Location.SelectedValue) != "")
            {
                string[] _LocationDetails = Convert.ToString(drp_Location.SelectedValue).Split(',');
                if (_LocationDetails.Length > 0)
                {
                    oclsAPI.city = _LocationDetails[0].Trim();
                    oclsAPI.state = _LocationDetails[1].Trim();
                    oclsAPI.country = _LocationDetails[2].Trim();
                    oclsAPI.Zip = _LocationDetails[3].Trim();
                    DataTable dtRate = oclsAPI.GetTaxtRate();

                    gvRate.DataSource = dtRate;
                    gvRate.DataBind();
                }
            }
            else
            {
                gvRate.DataSource = null;
                gvRate.DataBind();
            }
        }

    }
}