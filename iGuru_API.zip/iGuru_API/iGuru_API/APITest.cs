﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using Taxjar;

namespace iGuru_API
{
    public class APITest
    {
        TaxjarApi client = new TaxjarApi(ConfigurationManager.AppSettings["TaxjarApiKey"]);
        public DataTable GetTaxtRate()
        {
            DataTable dtList = new DataTable();
            dtList.Columns.Add("Name", typeof(string));
            dtList.Columns.Add("Rate", typeof(decimal));

            try
            {

                var rates = client.RatesForLocation(Zip, new
                {
                    city = city,
                    state = state,
                    country = country
                });
                if (rates != null)
                {
                    DataRow drCountry = dtList.NewRow();
                    drCountry["Name"] = "City Rate";
                    drCountry["Rate"] = Convert.ToDecimal(rates.CityRate);
                    dtList.Rows.Add(drCountry);

                    DataRow drCombinedRate = dtList.NewRow();
                    drCombinedRate["Name"] = "Combined Rate";
                    drCombinedRate["Rate"] = Convert.ToDecimal(rates.CombinedRate);
                    dtList.Rows.Add(drCombinedRate);

                    DataRow drCombinedDistrictRate = dtList.NewRow();
                    drCombinedDistrictRate["Name"] = "Combined DistrictRate";
                    drCombinedDistrictRate["Rate"] = Convert.ToDecimal(rates.CombinedDistrictRate);
                    dtList.Rows.Add(drCombinedDistrictRate);

                    DataRow drCont = dtList.NewRow();
                    drCont["Name"] = "Country Rate";
                    drCont["Rate"] = Convert.ToDecimal(rates.CountryRate);
                    dtList.Rows.Add(drCont);

                    DataRow drStateRate = dtList.NewRow();
                    drStateRate["Name"] = "State Rate";
                    drStateRate["Rate"] = Convert.ToDecimal(rates.StateRate);
                    dtList.Rows.Add(drStateRate);

                }
            }
            catch
            {
                dtList = new DataTable();
            }


            return dtList;
        }

        public string CalculateTax()
        {
            string _Result = "";
            try
            {
                var tax = client.TaxForOrder(new
                {
                    from_country = "US",
                    from_zip = "92093",
                    from_state = "CA",
                    from_city = "La Jolla",
                    to_country = country,
                    to_zip = Zip,
                    to_state = state,
                    shipping = Shipping,
                    line_items = (from rw in dt.AsEnumerable()
                                  select new
                                  {
                                      Id = Convert.ToString(rw["ItemCode"]),
                                      quantity = Convert.ToInt32(rw["Quantity"]),
                                      product_tax_code = Convert.ToString(rw["product_tax_code"]),
                                      unit_price = Convert.ToDecimal(rw["unit_price"]),
                                      discount = Convert.ToDecimal(rw["discount"])
                                  }).ToList()
                });
                _Result = "OrderTotalAmount : " + tax.OrderTotalAmount.ToString() + ". TaxableAmount : " + tax.TaxableAmount + ". Shipping Charge : " + tax.Shipping;
            }
            catch
            {

            }

            return _Result;
        }


        public decimal Shipping { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string Zip { get; set; }
        public DataTable dt { get; set; }
    }

}